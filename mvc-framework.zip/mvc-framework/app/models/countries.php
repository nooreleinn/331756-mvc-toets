<?php
namespace foo { 
class countries {
	private $db;

    public function __construct() {
        $this->db = new Database;
	}

    public function getcountries() {
        $this->db->query("SELECT * FROM countries");
        $result = $this->db->resultSet();
        return $result;
    }
}
}