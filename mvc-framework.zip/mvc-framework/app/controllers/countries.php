<?php
class countries extends Controller
{
  public function __construct()
  {
    $this->userModal = $this->model('Countries');
  }

  public function index()
  {
    $countries = $this->userModal->getcountries();

    $data = [
      'title' => 'Home page',
      'countries' => $countries
    ];
    $this->view('countries/index', $data);
  }

  public function about()
  {
    $this->view('countries/about');
  }
}