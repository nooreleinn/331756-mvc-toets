<?php
//Database params
define('DB_HOST', 'localhost'); 
define('DB_USER', 'root'); 
define('DB_PASS', ''); 
define('DB_NAME', 'mvcframework'); 

define('APPROOT', dirname(dirname(__FILE__)));

define('URLROOT', 'http://www.mvc-331756-framework.org/');

define('SITENAME', 'MVC Framework');