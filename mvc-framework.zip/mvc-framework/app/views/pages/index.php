<a href="http://www.mvc-331756-framework.org/countries/index">countries Index</a>

<?php
// echo $data['name'];
// echo URLROOT;
// var_dump($data);

// foreach ($data['users'] as $user) {
//   echo "Information: " . $user->user_name . $user->user_email;
//   echo "<br>";
// }
?>