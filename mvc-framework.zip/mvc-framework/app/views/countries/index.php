<a href="http://mvc-workbench.org/pages/index">Back to Homepage</a>

<h1>countries overzicht</h1>
<table>
  <tr>
    <th>id</th>
    <th>name</th>
    <th>capitalcity</th>
    <th>continent</th>
    <th>population</th>
  </tr>

  <?php
  foreach ($data['countries'] as $countries) {
    echo "<tr>";
    echo "<td>" . $countries->id . "</td>";
    echo "<td>" . $countries->name . "</td>";
    echo "<td>" . $countries->capitalcity . "</td>";
    echo "<td>" . $countries->continent . "</td>";
    echo "<td>" . $countries->population . "</td>";
    echo "</tr>";
  }
  ?>
</table>